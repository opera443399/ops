from django.conf.urls import url
from . import views

urlpatterns = [
    # ex: /charade/
    url(r'^$', views.index, name='index'),
    # ex: /charade/go
    url(r'^go/(?P<count>[0-9]+)/$', views.go, name='go'),
    # ex: /charade/list
    url(r'^list/$', views.list, name='list'),
    # ex: /charade/5/
    url(r'^(?P<pk>[0-9]+)/$', views.DetailView.as_view(), name='detail'),
]
