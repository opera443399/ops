from django.contrib import admin
from .models import Vocabulary

# Register your models here.

class VocabularyAdmin(admin.ModelAdmin):
    date_hierarchy = 'dt'
    list_display = ('en', 'zh', 'exp', 'dt')

admin.site.register(Vocabulary, VocabularyAdmin)
