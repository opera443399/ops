from django.contrib import admin
from .models import Vocabulary

# Register your models here.

class VocabularyAdmin(admin.ModelAdmin):
    date_hierarchy = 'dt'
    list_display = ('en', 'zh', 'exp', 'dt')
    fieldsets = [
        ('word', {'fields': ['en', 'zh']}),
        ('explanation', {'fields':['exp'], 'classes': ['collapse']}),
    ]
    list_filter = ['dt']
    search_fields = ['en']

admin.site.register(Vocabulary, VocabularyAdmin)
