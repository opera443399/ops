# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Vocabulary',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('en', models.CharField(max_length=200, verbose_name='en')),
                ('zh', models.CharField(max_length=100, verbose_name='zh')),
                ('exp', models.TextField(verbose_name='explain')),
                ('dt', models.DateTimeField(verbose_name='dt')),
            ],
        ),
    ]
