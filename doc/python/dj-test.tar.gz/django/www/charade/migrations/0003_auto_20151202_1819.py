# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('charade', '0002_auto_20151201_1848'),
    ]

    operations = [
        migrations.AlterField(
            model_name='vocabulary',
            name='dt',
            field=models.DateTimeField(auto_now=True, verbose_name='\u65f6\u95f4'),
        ),
        migrations.AlterField(
            model_name='vocabulary',
            name='en',
            field=models.CharField(unique=True, max_length=200, verbose_name='en'),
        ),
        migrations.AlterField(
            model_name='vocabulary',
            name='exp',
            field=models.TextField(verbose_name='\u89e3\u91ca'),
        ),
        migrations.AlterField(
            model_name='vocabulary',
            name='zh',
            field=models.CharField(max_length=100, verbose_name='\u4e2d\u6587'),
        ),
    ]
