# coding: utf-8
from __future__ import unicode_literals
from django.utils.encoding import python_2_unicode_compatible

from django.db import models

# Create your models here.

@python_2_unicode_compatible
class Vocabulary(models.Model):
    en = models.CharField('en', max_length=200)
    zh = models.CharField('zh', max_length=100)
    exp = models.TextField('explain')

    dt = models.DateTimeField('dt', auto_now=True)

    def __str__(self):
        return self.en
