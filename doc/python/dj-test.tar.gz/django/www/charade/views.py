from django.shortcuts import get_object_or_404, render
from django.http import HttpResponseRedirect
from django.core.urlresolvers import reverse
from django.views import generic
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

from .models import Vocabulary
import random

# Create your views here.
def index(request):
    return render(request, 'charade/index.html')

def go(request, count):
    """Return some words"""
    score = random.randint(1,3)
    tmp_word_list = Vocabulary.objects.order_by('?')[:count]
    paginator = Paginator(tmp_word_list, 1) # show 1 word per page
    page = request.GET.get('page')
    try:
        word_list = paginator.page(page)
    except PageNotAnInteger:
        word_list = paginator.page(1)
    except EmptyPage:
        word_list = paginator.page(paginator.num_pages)
    context = {
        'word_list': word_list,
        'score': score
    }

    return render(request, 'charade/go.html', context)


def list(request):
    """Return some words"""
    tmp_word_list = Vocabulary.objects.order_by('-dt')
    paginator = Paginator(tmp_word_list, 10) # show 10 word per page
    page = request.GET.get('page')
    try:
        word_list = paginator.page(page)
    except PageNotAnInteger:
        word_list = paginator.page(1)
    except EmptyPage:
        word_list = paginator.page(paginator.num_pages)
    context = {'word_list': word_list}

    return render(request, 'charade/list.html', context)

class DetailView(generic.DetailView):
    model = Vocabulary

