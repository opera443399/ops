run
---
python manage.py runserver 0.0.0.0:80

admin
-----
http://0.0.0.0/admin/
root
111111

debug
-----
www/setting.py: DEBUG=True
如果：DEBUG=False，则django不处理静态文件，此时应该配置nginx或apache来处理静态文件

nginx
-----
一、安装
[root@tvm01 ~]# yum install nginx
[root@tvm01 ~]# pip2.7 install uwsgi

二、配置
1、关闭django项目的 DEBUG 选项，并设置 ALLOWED_HOSTS 和 STATIC_ROOT ：
[root@tvm01 ~]# cd /opt/test-django/www
[root@tvm01 www]# vim www/settings.py
DEBUG = False

ALLOWED_HOSTS = ['*']

STATIC_ROOT = os.path.join(BASE_DIR,'static')

2、收集django项目的static文件：
[root@tvm01 www]# python manage.py collectstatic

3、使用uwsgi来运行django服务：
[root@tvm01 www]# /usr/local/bin/uwsgi --http 127.0.0.1:8090 --chdir /opt/test-django/www --module www.wsgi >/var/log/nginx/uwsgi.log 2>&1 & 


4、使用nginx来处理静态文件：
[root@tvm01 www]# cat /etc/nginx/conf.d/www.conf 
upstream backend {
    server 127.0.0.1:8090;
}

server {
    listen 80 default;
    server_name www.test.com;
    charset utf-8;
    
    location /static {
        alias /opt/test-django/www/static;
    }

    location / {
        proxy_pass http://backend;
    }
}
[root@tvm01 www]# service nginx start
