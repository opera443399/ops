from django.shortcuts import get_object_or_404, render
from django.http import HttpResponseRedirect, HttpResponse
from django.core.urlresolvers import reverse
from django.views import generic
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

from .models import Vocabulary, GameTemporaryTable, GameScoreBoard
import random

# Create your views here.
def index(request):
    return render(request, 'charade/index.html')

def game_set(request, count=20):
    """fetch some words into temporary table"""
    GameTemporaryTable.objects.all().delete()
    tmp_word_list = Vocabulary.objects.order_by('?')[:count]
    tmp_board = GameScoreBoard.objects.create(number=count)
    tmp_table = GameScoreBoard.objects.get(pk=tmp_board.id)
    for w in tmp_word_list:
        tmp_table.gametemporarytable_set.create(en=w.en, zh=w.zh)

    return HttpResponseRedirect(reverse('charade:game_play', args=(tmp_board.id,)))


def game_play(request, board_id):
    """fetch one row """
    tmp_table = GameScoreBoard.objects.get(pk=board_id)
    tmp_word_list = tmp_table.gametemporarytable_set.exclude(used=1).order_by('?')[:1]

    context = {
        'word_list': tmp_word_list,
    }
    return render(request, 'charade/play.html', context)


def game_score(request, wid):
    tmp_table = GameTemporaryTable.objects.get(id=wid)
    tmp_table.score = request.POST['score']
    tmp_table.used = 1
    tmp_table.save()

    return HttpResponseRedirect(reverse('charade:game_play', args=(tmp_table.board_id,)))    
    


def game_go(request, count=20):
    """Return some words"""
    score = random.randint(1,3)
    tmp_word_list = Vocabulary.objects.order_by('?')[:count]
    paginator = Paginator(tmp_word_list, 1) # show 1 word per page
    page = request.GET.get('page')
    try:
        word_list = paginator.page(page)
    except PageNotAnInteger:
        word_list = paginator.page(1)
    except EmptyPage:
        word_list = paginator.page(paginator.num_pages)
    context = {
        'word_list': word_list,
        'score': score
    }

    return render(request, 'charade/go.html', context)


def game_list(request):
    """Return some words"""
    tmp_word_list = Vocabulary.objects.order_by('-dt')
    paginator = Paginator(tmp_word_list, 10) # show 10 word per page
    page = request.GET.get('page')
    try:
        word_list = paginator.page(page)
    except PageNotAnInteger:
        word_list = paginator.page(1)
    except EmptyPage:
        word_list = paginator.page(paginator.num_pages)
    context = {'word_list': word_list}

    return render(request, 'charade/list.html', context)

class GameDetailView(generic.DetailView):
    model = Vocabulary

