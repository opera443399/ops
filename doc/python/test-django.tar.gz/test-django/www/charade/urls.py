from django.conf.urls import url
from . import views

urlpatterns = [
    # ex: /charade/
    url(r'^$', views.index, name='index'),
    # ex: /charade/go
    url(r'^go/(?P<count>[0-9]+)/$', views.game_go, name='game_go'),
    # ex: /charade/set/10
    url(r'^set/(?P<count>[0-9]+)/$', views.game_set, name='game_set'),
    # ex: /charade/set/10/play
    url(r'^set/(?P<board_id>[0-9]+)/play/$', views.game_play, name='game_play'),
    # ex: /charade/set/10/play/en/score
    url(r'^set/(?P<wid>[0-9]+)/score/$', views.game_score, name='game_score'),
    # ex: /charade/list
    url(r'^list/$', views.game_list, name='game_list'),
    # ex: /charade/5/
    url(r'^(?P<pk>[0-9]+)/$', views.GameDetailView.as_view(), name='game_detail'),
]
