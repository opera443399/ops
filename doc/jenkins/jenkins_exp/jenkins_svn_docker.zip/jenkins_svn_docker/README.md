readme
------
2017/7/19


svn
-example
---project_name
------image_name
---------Dockerfile



svn->hook(post with parameter)->jenkins(with parameter)->run(script)