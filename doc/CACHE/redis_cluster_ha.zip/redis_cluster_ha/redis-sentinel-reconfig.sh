#!/bin/sh 
###  sentinel 触发执行此脚本时，会默认传递几个参数过来
###  <master-name> <role> <state> <from-ip> <from-port> <to-ip> <to-port>
#
master_name="$1"   ##monitor master-group-name
role="$2"
state="$3"
from_ip="$4"
from_port="$5"
to_ip="$6"
to_port="$7"

nutcracker_init="/etc/init.d/nutcracker"
nutcracker_conf="/etc/nutcracker/nutcracker.yml"
 
## 将新的master 端口和ip 替换掉 twemproxy 配置文件中旧的master 信息
sed -i "s/${from_ip}:${from_port}/${to_ip}:${to_port}/" ${nutcracker_conf}

## reload nutcracker
${nutcracker_init} reload
 
