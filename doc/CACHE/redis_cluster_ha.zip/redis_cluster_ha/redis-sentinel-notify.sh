#!/bin/bash

###  sentinel 触发执行此脚本时，会默认传递几个参数过来
###  <event type> <event description>
#

type="$1"
description="$2"


do_your_alert_script $type $description
