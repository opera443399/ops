[from]
----
https://github.com/shadowsocks/libQtShadowsocks/wiki/Installation
https://github.com/shadowsocks/libQtShadowsocks/tree/master/shadowsocks-libqss

[install]
---------
curl /etc/yum.repos.d/librehat-shadowsocks-epel-7.repo https://copr.fedorainfracloud.org/coprs/librehat/shadowsocks/repo/epel-7/librehat-shadowsocks-epel-7.repo
yum install *libQtShadowsocks* -y


[howto]
-------
# server
git clone https://github.com/shadowsocks/libQtShadowsocks.git
mkdir /etc/shadowsocks-libqss; cp libQtShadowsocks/shadowsocks-libqss/config.json /etc/shadowsocks-libqss

/usr/bin/shadowsocks-libqss -c /etc/shadowsocks-libqss/config.json -S --autoban >>/var/log/shadowsocks-libqss.log 2>&1 &

# client
# windows:
https://github.com/shadowsocks/shadowsocks-qt5/releases
