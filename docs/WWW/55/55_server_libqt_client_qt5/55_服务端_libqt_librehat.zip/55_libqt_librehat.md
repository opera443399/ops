[from]
----
https://github.com/shadowsocks/libQtShadowsocks/wiki/Installation
https://github.com/shadowsocks/libQtShadowsocks/tree/master/shadowsocks-libqss

[install]
---------
curl -O /etc/yum.repos.d/librehat-shadowsocks-epel-7.repo https://copr.fedorainfracloud.org/coprs/librehat/shadowsocks/repo/epel-7/librehat-shadowsocks-epel-7.repo
yum install *libQtShadowsocks* -y


[howto]
-------
# server
git clone https://github.com/shadowsocks/libQtShadowsocks.git
mkdir /etc/shadowsocks-libqss; cp libQtShadowsocks/shadowsocks-libqss/config.json /etc/shadowsocks-libqss

/usr/bin/shadowsocks-libqss -c /etc/shadowsocks-libqss/config.json -S --autoban >>/var/log/shadowsocks-libqss.log 2>&1 &

# client
# windows:
https://github.com/shadowsocks/shadowsocks-qt5/releases
curl -O ss-qt5-v2.8.0-win64.7z https://www.dropbox.com/sh/nqo84eld4z3lwe4/AAA_bE26clBh_BlPA-0gWeK-a/ss-qt5-v2.8.0-win64.7z?dl=0
